<?php
//header("Content-Type: text/html; charset=utf-8");
// Файлы phpmailer
require 'class.phpmailer.php';
require 'class.smtp.php';
// Переменные


$mail = new PHPMailer;
// $mail->isSMTP();
$mail->Host = 'smtp.yandex.ru'; // Тут укажите ваш SMTP сервер (Должен быть в админке хостинга)
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl';
$mail->CharSet = "utf-8";
$mail->Port = 465; // Тут нужно будет указать порт всё в той же админке
$mail->setFrom('info@novotechenergy.com'); // Ваш Email
$mail->addAddress('akan.nikolay@yandex.ru'); // Email получателя

//// Письмо

if($_POST['FrontPage'] == 'FrontPage'){
    $name = $_POST['name'];
    $email = $_POST['email'];
    

    $mail->isHTML(true);
    $mail->Subject = "Mail from web site - novotechenergy.com"; // Заголовок письма
    $mail->Body = ("
Name: $name
 <br />
E-mail: $email
<br /> 
");
}

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
       header('Location: https://novotechenergy.000webhostapp.com');
       
}
?>
